<?php

// Register shortcodes [trx_players] and [trx_players_table]
add_action('tennisclub_action_shortcodes_list',		'tennisclub_players_reg_shortcodes');
add_action('tennisclub_action_shortcodes_list',		'tennisclub_players_table_reg_shortcodes');
if (function_exists('tennisclub_exists_visual_composer') && tennisclub_exists_visual_composer()){
    add_action('tennisclub_action_shortcodes_list_vc','tennisclub_players_reg_shortcodes_vc');
    add_action('tennisclub_action_shortcodes_list_vc','tennisclub_players_table_reg_shortcodes_vc');
}





// ---------------------------------- [trx_players] ---------------------------------------

if ( !function_exists( 'tennisclub_sc_players' ) ) {
    function tennisclub_sc_players($atts, $content=null){
        if (tennisclub_in_shortcode_blogger()) return '';
        extract(tennisclub_html_decode(shortcode_atts(array(
            // Individual params
            "slider" => "no",
            "controls" => "no",
            "slides_space" => 0,
            "interval" => "",
            "autoheight" => "no",
            "align" => "",
            "custom" => "no",
            "ids" => "",
            "cat" => "",
            "count" => 3,
            "columns" => 3,
            "offset" => "",
            "orderby" => "date",
            "order" => "desc",
            "title" => "",
            "subtitle" => "",
            "description" => "",
            "link_caption" => esc_html__('Learn more', 'trx_utils'),
            "link" => '',
            "scheme" => '',
            // Common params
            "id" => "",
            "class" => "",
            "animation" => "",
            "css" => "",
            "width" => "",
            "height" => "",
            "top" => "",
            "bottom" => "",
            "left" => "",
            "right" => ""
        ), $atts)));
        $style = 'players-1';
        if (empty($id)) $id = "sc_players_".str_replace('.', '', mt_rand());
        if (empty($width)) $width = "100%";
        if (!empty($height) && tennisclub_param_is_on($autoheight)) $autoheight = "no";
        if (empty($interval)) $interval = mt_rand(5000, 10000);

        $class .= ($class ? ' ' : '') . tennisclub_get_css_position_as_classes($top, $right, $bottom, $left);

        $ws = tennisclub_get_css_dimensions_from_values($width);
        $hs = tennisclub_get_css_dimensions_from_values('', $height);
        $css .= ($hs) . ($ws);

        $count = max(1, (int) $count);
        $columns = max(1, min(12, (int) $columns));
        if (tennisclub_param_is_off($custom) && $count < $columns) $columns = $count;

        tennisclub_storage_set('sc_players_data', array(
                'id' => $id,
                'style' => $style,
                'columns' => $columns,
                'counter' => 0,
                'slider' => $slider,
                'css_wh' => $ws . $hs
            )
        );

        if (tennisclub_param_is_on($slider)) tennisclub_enqueue_slider('swiper');

        $output = '<div' . ($id ? ' id="'.esc_attr($id).'_wrap"' : '')
            . ' class="sc_players_wrap'
            . ($scheme && !tennisclub_param_is_off($scheme) && !tennisclub_param_is_inherit($scheme) ? ' scheme_'.esc_attr($scheme) : '')
            .'">'
            . '<div' . ($id ? ' id="'.esc_attr($id).'"' : '')
            . ' class="sc_players sc_players_style_'.esc_attr($style)
            . ' ' . esc_attr(tennisclub_get_template_property($style, 'container_classes'))
            . ' ' . esc_attr(tennisclub_get_slider_controls_classes($controls))
            . (tennisclub_param_is_on($slider)
                ? ' sc_slider_swiper swiper-slider-container'
                . (tennisclub_param_is_on($autoheight) ? ' sc_slider_height_auto' : '')
                . ($hs ? ' sc_slider_height_fixed' : '')
                : '')
            . (!empty($class) ? ' '.esc_attr($class) : '')
            . ($align!='' && $align!='none' ? ' align'.esc_attr($align) : '')
            .'"'
            . ($css!='' ? ' style="'.esc_attr($css).'"' : '')
            . (!empty($width) && tennisclub_strpos($width, '%')===false ? ' data-old-width="' . esc_attr($width) . '"' : '')
            . (!empty($height) && tennisclub_strpos($height, '%')===false ? ' data-old-height="' . esc_attr($height) . '"' : '')
            . ((int) $interval > 0 ? ' data-interval="'.esc_attr($interval).'"' : '')
            . ($slides_space > 0 ? ' data-slides-space="' . esc_attr($slides_space) . '"' : '')
            . ($columns > 1 ? ' data-slides-per-view="' . esc_attr($columns) . '"' : '')
            . ' data-slides-min-width="250"'
            . (!tennisclub_param_is_off($animation) ? ' data-animation="'.esc_attr(tennisclub_get_animation_classes($animation)).'"' : '')
            . '>'
            . (!empty($subtitle) ? '<h6 class="sc_players_subtitle sc_item_subtitle">' . trim(tennisclub_strmacros($subtitle)) . '</h6>' : '')
            . (!empty($title) ? '<h2 class="sc_players_title sc_item_title' . (empty($description) ? ' sc_item_title_without_descr' : ' sc_item_title_without_descr') . '">' . trim(tennisclub_strmacros($title)) . '</h2>' : '')
            . (!empty($description) ? '<div class="sc_players_descr sc_item_descr">' . trim(tennisclub_strmacros($description)) . '</div>' : '')
            . (tennisclub_param_is_on($slider)
                ? '<div class="slides swiper-wrapper">'
                : ($columns > 1
                    ? '<div class="sc_columns columns_wrap">'
                    : '')
            );


        global $post;

        if (!empty($ids)) {
            $posts = explode(',', $ids);
            $count = count($posts);
        }

        $args = array(
            'post_type' => 'players',
            'post_status' => 'publish',
            'posts_per_page' => $count,
            'ignore_sticky_posts' => true,
            'order' => $order=='asc' ? 'asc' : 'desc',
        );

        if ($offset > 0 && empty($ids)) {
            $args['offset'] = $offset;
        }

        $args = tennisclub_query_add_sort_order($args, $orderby, $order);
        $args = tennisclub_query_add_posts_and_cats($args, $ids, 'players', $cat, 'players_group');
        $query = new WP_Query( $args );

        $post_number = 0;

        while ( $query->have_posts() ) {
            $query->the_post();
            $post_number++;
            $args = array(
                'layout' => $style,
                'show' => false,
                'number' => $post_number,
                'posts_on_page' => ($count > 0 ? $count : $query->found_posts),
                "descr" => tennisclub_get_custom_option('post_excerpt_maxlength'.($columns > 1 ? '_masonry' : '')),
                "orderby" => $orderby,
                'content' => false,
                'terms_list' => false,
                "columns_count" => $columns,
                'slider' => $slider,
                'tag_id' => $id ? $id . '_' . $post_number : '',
                'tag_class' => '',
                'tag_animation' => '',
                'tag_css' => '',
                'tag_css_wh' => $ws . $hs
            );
            $post_data = tennisclub_get_post_data($args);
            $post_meta = get_post_meta($post_data['post_id'], tennisclub_storage_get('options_prefix') . '_post_options', true);
            $thumb_sizes = tennisclub_get_thumb_sizes(array('layout' => $style));
            $args['country'] = $post_meta['player_country'];
            $args['club'] = $post_meta['player_club'];
            $args['type'] = $post_meta['player_type'];
            $args['age'] = $post_meta['player_age'];
            $args['link'] = $post_data['post_link'];
            $args['photo'] = $post_data['post_thumb'];
            $mult = tennisclub_get_retina_multiplier();
            if (empty($args['photo']) && !empty($args['email'])) $args['photo'] = get_avatar($args['email'], $thumb_sizes['w']*$mult);
            $args['socials'] = '';
            if (!empty($post_meta['player_socials']) && !tennisclub_param_is_inherit($post_meta['player_socials']))
                $args['socials'] = tennisclub_do_shortcode('[trx_socials size="tiny" shape="round" socials="'.esc_attr($post_meta['player_socials']).'"][/trx_socials]');

            $output .= tennisclub_show_post_layout($args, $post_data);
        }
        wp_reset_postdata();


        if (tennisclub_param_is_on($slider)) {
            $output .= '</div>'
                . '<div class="sc_slider_controls_wrap"><a class="sc_slider_prev" href="#"></a><a class="sc_slider_next" href="#"></a></div>'
                . '<div class="sc_slider_pagination_wrap"></div>';
        } else if ($columns > 1) {
            $output .= '</div>';
        }

        $output .= (!empty($link) ? '<div class="sc_players_button sc_item_button">'.tennisclub_do_shortcode('[trx_button link="'.esc_url($link).'" icon="icon-right"]'.esc_html($link_caption).'[/trx_button]').'</div>' : '')
            . '</div><!-- /.sc_players -->'
            . '</div><!-- /.sc_players_wrap -->';

        // Add template specific scripts and styles
        do_action('tennisclub_action_blog_scripts', $style);

        return apply_filters('tennisclub_shortcode_output', $output, 'trx_players', $atts, $content);
    }
    add_shortcode('trx_players', 'tennisclub_sc_players');
}

// ---------------------------------- [/trx_players] ---------------------------------------



// ---------------------------------- [trx_players_table] ---------------------------------------

if ( !function_exists( 'tennisclub_sc_players_table' ) ) {
    function tennisclub_sc_players_table($atts, $content=null){
        if (tennisclub_in_shortcode_blogger()) return '';
        extract(tennisclub_html_decode(shortcode_atts(array(
            // Individual params
            "style" => "1",
            "cat" => "",
            "title" => "",
            "subtitle" => "",
            "description" => "",
            "link_caption" => esc_html__('Learn more', 'trx_utils'),
            "link" => '',
            "scheme" => '',
            "align" => "",
            // Common params
            "id" => "",
            "class" => "",
            "animation" => "",
            "css" => "",
            "width" => "",
            "height" => "",
            "top" => "",
            "bottom" => "",
            "left" => "",
            "right" => ""
        ), $atts)));
        $output = '';

        if (empty($id)) $id = "sc_players_table_".str_replace('.', '', mt_rand());
        if (empty($width)) $width = "100%";
        if (!empty($height) && tennisclub_param_is_on($autoheight)) $autoheight = "no";

        $class .= ($class ? ' ' : '') . tennisclub_get_css_position_as_classes($top, $right, $bottom, $left);

        $ws = tennisclub_get_css_dimensions_from_values($width);
        $hs = tennisclub_get_css_dimensions_from_values('', $height);
        $css .= ($hs) . ($ws);

        $output = '<div' . ($id ? ' id="'.esc_attr($id).'_wrap"' : '')
            . ' class="sc_players_table_wrap'
            . ($scheme && !tennisclub_param_is_off($scheme) && !tennisclub_param_is_inherit($scheme) ? ' scheme_'.esc_attr($scheme) : '')
            .'">'
            .'<div' . ($id ? ' id="'.esc_attr($id).'"' : '')
            . ' class="sc_players_table style_'.$style
            . (!empty($class) ? ' '.esc_attr($class) : '')
            . ($align!='' && $align!='none' ? ' align'.esc_attr($align) : '')
            .'"'
            . (!empty($width) && tennisclub_strpos($width, '%')===false ? ' data-old-width="' . esc_attr($width) . '"' : '')
            . (!empty($height) && tennisclub_strpos($height, '%')===false ? ' data-old-height="' . esc_attr($height) . '"' : '')
            . ($css!='' ? ' style="'.esc_attr($css).'"' : '')
            . (!tennisclub_param_is_off($animation) ? ' data-animation="'.esc_attr(tennisclub_get_animation_classes($animation)).'"' : '')
            . ' data-sort="asc"'
            . '>'
            . (!empty($subtitle) ? '<h6 class="sc_players_table_subtitle sc_item_subtitle">' . trim(tennisclub_strmacros($subtitle)) . '</h6>' : '')
            . (!empty($title) ? '<h2 class="sc_players_table_title sc_item_title' . (empty($description) ? ' sc_item_title_without_descr' : ' sc_item_title_without_descr') . '">' . trim(tennisclub_strmacros($title)) . '</h2>' : '')
            . (!empty($description) ? '<div class="sc_players_table_descr sc_item_descr">' . trim(tennisclub_strmacros($description)) . '</div>' : '');


        $matches = array();
        $categories = '';
        $table = array();

        if(!empty($cat))
            $matches = tennisclub_get_matches_by_term($cat);
        else{
            $terms = get_terms( 'matches_group' );
            if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
                $output .= '<div class="sc_players_table_category"><div class="label">'.esc_html__('Select category', 'trx_utils').'</div><select>';
                $output .= '<option data-cat="all">'.esc_html__('All', 'trx_utils').'</option>';

                foreach ( $terms as $term ) {
                    $matches = array_merge($matches, tennisclub_get_matches_by_term($term->term_id));
                    $output .= '<option data-cat="'.$term->term_id.'">'.$term->name.'</option>';
                }

                $output .= '<select></div>';
            }
        }

        if(!empty($matches)){
            foreach ( $matches as $match ) {
                $post_meta = get_post_meta($match->object_id, tennisclub_storage_get('options_prefix') . '_post_options', true);

                $post_categories = wp_get_post_terms( $match->object_id,  'matches_group');

                foreach($post_categories as $c){
                    $cat = get_category( $c );
                    $categories .= $cat->term_id.'|' ;
                }

                $player = $post_meta['match_player_1'];
                $player_obj = (intval($player) > 0 ? get_post($player, OBJECT) : get_page_by_title($player, OBJECT, 'players'));
                $player_id = $player_obj->ID;

                if(!array_key_exists($player_id, $table))
                    $table[$player_id] = array( 0 => get_post_meta($player_id, tennisclub_storage_get('options_prefix').'_points', true), 1 => $categories);

                $player = $post_meta['match_player_2'];
                $player_obj = (intval($player) > 0 ? get_post($player, OBJECT) : get_page_by_title($player, OBJECT, 'players'));
                $player_id = $player_obj->ID;

                if(!array_key_exists($player_id, $table))
                    $table[$player_id] = array( 0 => get_post_meta($player_id, tennisclub_storage_get('options_prefix').'_points', true), 1 => $categories);

                $categories = '';
            }
        }

        if (!empty($table)) {

            tennisclub_storage_set_array('js_vars', 'ajax_'.trim($id), serialize($table));
            $output .= tennisclub_get_players_table('asc', $table);
        }

        $output .= (!empty($link) ? '<div class="sc_players_table_button sc_item_button">'.tennisclub_do_shortcode('[trx_button link="'.esc_url($link).'" icon="icon-right"]'.esc_html($link_caption).'[/trx_button]').'</div>' : '')
            . '</div><!-- /.sc_players_table -->'
            . '</div><!-- /.sc_players_table_wrap -->';

        return apply_filters('tennisclub_shortcode_output', $output, 'trx_players_table', $atts, $content);
    }
    add_shortcode('trx_players_table', 'tennisclub_sc_players_table');
}
// ---------------------------------- [/trx_players_table] ---------------------------------------



// Add [trx_players] in the shortcodes list
if (!function_exists('tennisclub_players_reg_shortcodes')) {

    function tennisclub_players_reg_shortcodes() {
        if (tennisclub_storage_isset('shortcodes')) {

            $players_groups = tennisclub_get_list_terms(false, 'players_group');
            $controls	 = tennisclub_get_list_slider_controls();

            tennisclub_sc_map_after('trx_tabs', array(

                // Players
                "trx_players" => array(
                    "title" => esc_html__("Players", 'trx_utils'),
                    "desc" => wp_kses_data( __("Insert players in your page (post)", 'trx_utils') ),
                    "decorate" => true,
                    "container" => false,
                    "params" => array(
                        "title" => array(
                            "title" => esc_html__("Title", 'trx_utils'),
                            "desc" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "subtitle" => array(
                            "title" => esc_html__("Subtitle", 'trx_utils'),
                            "desc" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "description" => array(
                            "title" => esc_html__("Description", 'trx_utils'),
                            "desc" => wp_kses_data( __("Short description for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "textarea"
                        ),
                        "columns" => array(
                            "title" => esc_html__("Columns", 'trx_utils'),
                            "desc" => wp_kses_data( __("How many columns use to show players", 'trx_utils') ),
                            "value" => 3,
                            "min" => 2,
                            "max" => 5,
                            "step" => 1,
                            "type" => "spinner"
                        ),
                        "scheme" => array(
                            "title" => esc_html__("Color scheme", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                            "value" => "",
                            "type" => "checklist",
                            "options" => tennisclub_get_sc_param('schemes')
                        ),
                        "slider" => array(
                            "title" => esc_html__("Slider", 'trx_utils'),
                            "desc" => wp_kses_data( __("Use slider to show players", 'trx_utils') ),
                            "value" => "no",
                            "type" => "switch",
                            "options" => tennisclub_get_sc_param('yes_no')
                        ),
                        "controls" => array(
                            "title" => esc_html__("Controls", 'trx_utils'),
                            "desc" => wp_kses_data( __("Slider controls style and position", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "divider" => true,
                            "value" => "",
                            "type" => "checklist",
                            "dir" => "horizontal",
                            "options" => $controls
                        ),
                        "slides_space" => array(
                            "title" => esc_html__("Space between slides", 'trx_utils'),
                            "desc" => wp_kses_data( __("Size of space (in px) between slides", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "value" => 0,
                            "min" => 0,
                            "max" => 100,
                            "step" => 10,
                            "type" => "spinner"
                        ),
                        "interval" => array(
                            "title" => esc_html__("Slides change interval", 'trx_utils'),
                            "desc" => wp_kses_data( __("Slides change interval (in milliseconds: 1000ms = 1s)", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "value" => 7000,
                            "step" => 500,
                            "min" => 0,
                            "type" => "spinner"
                        ),
                        "autoheight" => array(
                            "title" => esc_html__("Autoheight", 'trx_utils'),
                            "desc" => wp_kses_data( __("Change whole slider's height (make it equal current slide's height)", 'trx_utils') ),
                            "dependency" => array(
                                'slider' => array('yes')
                            ),
                            "value" => "yes",
                            "type" => "switch",
                            "options" => tennisclub_get_sc_param('yes_no')
                        ),
                        "align" => array(
                            "title" => esc_html__("Alignment", 'trx_utils'),
                            "desc" => wp_kses_data( __("Alignment of the players block", 'trx_utils') ),
                            "divider" => true,
                            "value" => "",
                            "type" => "checklist",
                            "dir" => "horizontal",
                            "options" => tennisclub_get_sc_param('align')
                        ),
                        "cat" => array(
                            "title" => esc_html__("Categories", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select categories (groups) to show players. If empty - select players from any category (group) or from IDs list", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "divider" => true,
                            "value" => "",
                            "type" => "select",
                            "style" => "list",
                            "multiple" => true,
                            "options" => tennisclub_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $players_groups)
                        ),
                        "count" => array(
                            "title" => esc_html__("Number of posts", 'trx_utils'),
                            "desc" => wp_kses_data( __("How many posts will be displayed? If used IDs - this parameter ignored.", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => 3,
                            "min" => 1,
                            "max" => 100,
                            "type" => "spinner"
                        ),
                        "offset" => array(
                            "title" => esc_html__("Offset before select posts", 'trx_utils'),
                            "desc" => wp_kses_data( __("Skip posts before select next part.", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => 0,
                            "min" => 0,
                            "type" => "spinner"
                        ),
                        "orderby" => array(
                            "title" => esc_html__("Post order by", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select desired posts sorting method", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => "title",
                            "type" => "select",
                            "options" => tennisclub_get_sc_param('sorting')
                        ),
                        "order" => array(
                            "title" => esc_html__("Post order", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select desired posts order", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => "asc",
                            "type" => "switch",
                            "size" => "big",
                            "options" => tennisclub_get_sc_param('ordering')
                        ),
                        "ids" => array(
                            "title" => esc_html__("Post IDs list", 'trx_utils'),
                            "desc" => wp_kses_data( __("Comma separated list of posts ID. If set - parameters above are ignored!", 'trx_utils') ),
                            "dependency" => array(
                                'custom' => array('no')
                            ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "link" => array(
                            "title" => esc_html__("Button URL", 'trx_utils'),
                            "desc" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "link_caption" => array(
                            "title" => esc_html__("Button caption", 'trx_utils'),
                            "desc" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "width" => tennisclub_shortcodes_width(),
                        "height" => tennisclub_shortcodes_height(),
                        "top" => tennisclub_get_sc_param('top'),
                        "bottom" => tennisclub_get_sc_param('bottom'),
                        "left" => tennisclub_get_sc_param('left'),
                        "right" => tennisclub_get_sc_param('right'),
                        "id" => tennisclub_get_sc_param('id'),
                        "class" => tennisclub_get_sc_param('class'),
                        "animation" => tennisclub_get_sc_param('animation'),
                        "css" => tennisclub_get_sc_param('css')
                    )
                )

            ));
        }
    }
}


// Add [trx_players_table] in the shortcodes list
if (!function_exists('tennisclub_players_table_reg_shortcodes')) {

    function tennisclub_players_table_reg_shortcodes() {
        if (tennisclub_storage_isset('shortcodes')) {

            $matches_groups = tennisclub_get_list_terms(false, 'matches_group');
            $controls	 = tennisclub_get_list_slider_controls();

            tennisclub_sc_map_after('trx_tabs', array(

                // Players Table
                "trx_players_table" => array(
                    "title" => esc_html__("Players Table", 'trx_utils'),
                    "desc" => wp_kses_data( __("Insert players table in your page (post)", 'trx_utils') ),
                    "decorate" => true,
                    "container" => false,
                    "params" => array(
                        "style" => array(
                            "title" => esc_html__("Style", 'trx_utils'),
                            "desc" => wp_kses_data( __("Style of the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "select",
                            "options" => array(
                                '1'  => esc_html__('Style 1', 'trx_utils'),
                                '2' => esc_html__('Style 2', 'trx_utils')
                            ),
                            "type" => "checklist"
                        ),
                        "title" => array(
                            "title" => esc_html__("Title", 'trx_utils'),
                            "desc" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "subtitle" => array(
                            "title" => esc_html__("Subtitle", 'trx_utils'),
                            "desc" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "description" => array(
                            "title" => esc_html__("Description", 'trx_utils'),
                            "desc" => wp_kses_data( __("Short description for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "textarea"
                        ),
                        "scheme" => array(
                            "title" => esc_html__("Color scheme", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                            "value" => "",
                            "type" => "checklist",
                            "options" => tennisclub_get_sc_param('schemes')
                        ),
                        "cat" => array(
                            "title" => esc_html__("Categories", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select categories (groups) to show players.", 'trx_utils') ),
                            "divider" => true,
                            "value" => "",
                            "type" => "select",
                            "style" => "list",
                            "multiple" => true,
                            "options" => tennisclub_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $matches_groups)
                        ),
                        "align" => array(
                            "title" => esc_html__("Alignment", 'trx_utils'),
                            "desc" => wp_kses_data( __("Alignment of the players table", 'trx_utils') ),
                            "divider" => true,
                            "value" => "",
                            "type" => "checklist",
                            "dir" => "horizontal",
                            "options" => tennisclub_get_sc_param('align')
                        ),
                        "link" => array(
                            "title" => esc_html__("Button URL", 'trx_utils'),
                            "desc" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "link_caption" => array(
                            "title" => esc_html__("Button caption", 'trx_utils'),
                            "desc" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "width" => tennisclub_shortcodes_width(),
                        "height" => tennisclub_shortcodes_height(),
                        "top" => tennisclub_get_sc_param('top'),
                        "bottom" => tennisclub_get_sc_param('bottom'),
                        "left" => tennisclub_get_sc_param('left'),
                        "right" => tennisclub_get_sc_param('right'),
                        "id" => tennisclub_get_sc_param('id'),
                        "class" => tennisclub_get_sc_param('class'),
                        "animation" => tennisclub_get_sc_param('animation'),
                        "css" => tennisclub_get_sc_param('css')
                    )
                )

            ));
        }
    }
}



// Add [trx_players] in the VC shortcodes list
if (!function_exists('tennisclub_players_reg_shortcodes_vc')) {

    function tennisclub_players_reg_shortcodes_vc() {

        $players_groups = tennisclub_get_list_terms(false, 'players_group');
        $controls	 = tennisclub_get_list_slider_controls();

        // Players
        vc_map( array(
            "base" => "trx_players",
            "name" => esc_html__("Players", 'trx_utils'),
            "description" => wp_kses_data( __("Insert players", 'trx_utils') ),
            "category" => esc_html__('Content', 'trx_utils'),
            'icon' => 'icon_trx_players',
            "class" => "trx_sc_single trx_sc_players",
            "content_element" => true,
            "is_container" => false,
            "show_settings_on_create" => true,
            "params" => array(
                array(
                    "param_name" => "scheme",
                    "heading" => esc_html__("Color scheme", 'trx_utils'),
                    "description" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                    "class" => "",
                    "value" => array_flip(tennisclub_get_sc_param('schemes')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "slider",
                    "heading" => esc_html__("Slider", 'trx_utils'),
                    "description" => wp_kses_data( __("Use slider to show players", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Slider', 'trx_utils'),
                    "class" => "",
                    "std" => "no",
                    "value" => array_flip(tennisclub_get_sc_param('yes_no')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "controls",
                    "heading" => esc_html__("Controls", 'trx_utils'),
                    "description" => wp_kses_data( __("Slider controls style and position", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "std" => "no",
                    "value" => array_flip($controls),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "slides_space",
                    "heading" => esc_html__("Space between slides", 'trx_utils'),
                    "description" => wp_kses_data( __("Size of space (in px) between slides", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "value" => "0",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "interval",
                    "heading" => esc_html__("Slides change interval", 'trx_utils'),
                    "description" => wp_kses_data( __("Slides change interval (in milliseconds: 1000ms = 1s)", 'trx_utils') ),
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "value" => "7000",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "autoheight",
                    "heading" => esc_html__("Autoheight", 'trx_utils'),
                    "description" => wp_kses_data( __("Change whole slider's height (make it equal current slide's height)", 'trx_utils') ),
                    "group" => esc_html__('Slider', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'slider',
                        'value' => 'yes'
                    ),
                    "class" => "",
                    "value" => array("Autoheight" => "yes" ),
                    "type" => "checkbox"
                ),
                array(
                    "param_name" => "align",
                    "heading" => esc_html__("Alignment", 'trx_utils'),
                    "description" => wp_kses_data( __("Alignment of the players block", 'trx_utils') ),
                    "class" => "",
                    "value" => array_flip(tennisclub_get_sc_param('align')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "title",
                    "heading" => esc_html__("Title", 'trx_utils'),
                    "description" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "subtitle",
                    "heading" => esc_html__("Subtitle", 'trx_utils'),
                    "description" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "description",
                    "heading" => esc_html__("Description", 'trx_utils'),
                    "description" => wp_kses_data( __("Description for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textarea"
                ),
                array(
                    "param_name" => "cat",
                    "heading" => esc_html__("Categories", 'trx_utils'),
                    "description" => wp_kses_data( __("Select category to show players. If empty - select players from any category (group) or from IDs list", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => array_flip(tennisclub_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $players_groups)),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "columns",
                    "heading" => esc_html__("Columns", 'trx_utils'),
                    "description" => wp_kses_data( __("How many columns use to show players", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    "admin_label" => true,
                    "class" => "",
                    "value" => "3",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "count",
                    "heading" => esc_html__("Number of posts", 'trx_utils'),
                    "description" => wp_kses_data( __("How many posts will be displayed? If used IDs - this parameter ignored.", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => "3",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "offset",
                    "heading" => esc_html__("Offset before select posts", 'trx_utils'),
                    "description" => wp_kses_data( __("Skip posts before select next part.", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => "0",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "orderby",
                    "heading" => esc_html__("Post sorting", 'trx_utils'),
                    "description" => wp_kses_data( __("Select desired posts sorting method", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => array_flip(tennisclub_get_sc_param('sorting')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "order",
                    "heading" => esc_html__("Post order", 'trx_utils'),
                    "description" => wp_kses_data( __("Select desired posts order", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => array_flip(tennisclub_get_sc_param('ordering')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "ids",
                    "heading" => esc_html__("Player's IDs list", 'trx_utils'),
                    "description" => wp_kses_data( __("Comma separated list of players's ID. If set - parameters above (category, count, order, etc.)  are ignored!", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "link",
                    "heading" => esc_html__("Button URL", 'trx_utils'),
                    "description" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "link_caption",
                    "heading" => esc_html__("Button caption", 'trx_utils'),
                    "description" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                tennisclub_vc_width(),
                tennisclub_vc_height(),
                tennisclub_get_vc_param('margin_top'),
                tennisclub_get_vc_param('margin_bottom'),
                tennisclub_get_vc_param('margin_left'),
                tennisclub_get_vc_param('margin_right'),
                tennisclub_get_vc_param('id'),
                tennisclub_get_vc_param('class'),
                tennisclub_get_vc_param('animation'),
                tennisclub_get_vc_param('css')
            )
        ) );
        class WPBakeryShortCode_Trx_Players extends Tennisclub_VC_ShortCodeSingle {}
    }
}


// Add [trx_players_table] in the VC shortcodes list
if (!function_exists('tennisclub_players_table_reg_shortcodes_vc')) {

    function tennisclub_players_table_reg_shortcodes_vc() {

        $matches_groups = tennisclub_get_list_terms(false, 'matches_group');
        $controls	 = tennisclub_get_list_slider_controls();

        // Players Table
        vc_map( array(
            "base" => "trx_players_table",
            "name" => esc_html__("Players Table", 'trx_utils'),
            "description" => wp_kses_data( __("Insert players table", 'trx_utils') ),
            "category" => esc_html__('Content', 'trx_utils'),
            'icon' => 'icon_trx_players',
            "class" => "trx_sc_single trx_sc_players_table",
            "content_element" => true,
            "is_container" => false,
            "show_settings_on_create" => true,
            "params" => array(
                array(
                    "param_name" => "style",
                    "heading" => esc_html__("Table style", 'trx_utils'),
                    "description" => wp_kses_data( __("Style of the block", 'trx_utils') ),
                    "class" => "",
                    "value" => array(
                        esc_html__('Style 1', 'trx_utils') => '1',
                        esc_html__('Style 2', 'trx_utils') => '2'
                    ),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "align",
                    "heading" => esc_html__("Alignment", 'trx_utils'),
                    "description" => wp_kses_data( __("Alignment of the players table", 'trx_utils') ),
                    "class" => "",
                    "value" => array_flip(tennisclub_get_sc_param('align')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "scheme",
                    "heading" => esc_html__("Color scheme", 'trx_utils'),
                    "description" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                    "class" => "",
                    "value" => array_flip(tennisclub_get_sc_param('schemes')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "title",
                    "heading" => esc_html__("Title", 'trx_utils'),
                    "description" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "subtitle",
                    "heading" => esc_html__("Subtitle", 'trx_utils'),
                    "description" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "description",
                    "heading" => esc_html__("Description", 'trx_utils'),
                    "description" => wp_kses_data( __("Description for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textarea"
                ),
                array(
                    "param_name" => "cat",
                    "heading" => esc_html__("Categories", 'trx_utils'),
                    "description" => wp_kses_data( __("Select category to show players. If empty - select players from any category (group) or from IDs list", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => array_flip(tennisclub_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $matches_groups)),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "link",
                    "heading" => esc_html__("Button URL", 'trx_utils'),
                    "description" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "link_caption",
                    "heading" => esc_html__("Button caption", 'trx_utils'),
                    "description" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                tennisclub_vc_width(),
                tennisclub_vc_height(),
                tennisclub_get_vc_param('margin_top'),
                tennisclub_get_vc_param('margin_bottom'),
                tennisclub_get_vc_param('margin_left'),
                tennisclub_get_vc_param('margin_right'),
                tennisclub_get_vc_param('id'),
                tennisclub_get_vc_param('class'),
                tennisclub_get_vc_param('animation'),
                tennisclub_get_vc_param('css')
            )
        ) );
        class WPBakeryShortCode_Trx_Players_Table extends Tennisclub_VC_ShortCodeSingle {}
    }
}

