<?php
if (!function_exists('tennisclub_theme_shortcodes_setup')) {
	add_action( 'tennisclub_action_before_init_theme', 'tennisclub_theme_shortcodes_setup', 1 );
	function tennisclub_theme_shortcodes_setup() {
		add_filter('tennisclub_filter_googlemap_styles', 'tennisclub_theme_shortcodes_googlemap_styles');
	}
}


// Add theme-specific Google map styles
if ( !function_exists( 'tennisclub_theme_shortcodes_googlemap_styles' ) ) {
	function tennisclub_theme_shortcodes_googlemap_styles($list) {
		$list['simple']		= esc_html__('Simple', 'trx_utils');
		$list['greyscale']	= esc_html__('Greyscale', 'trx_utils');
		$list['inverse']	= esc_html__('Inverse', 'trx_utils');
		$list['dark']		= esc_html__('Dark', 'trx_utils');
		$list['custom']		= esc_html__('Custom', 'trx_utils');
		return $list;
	}
}
?>