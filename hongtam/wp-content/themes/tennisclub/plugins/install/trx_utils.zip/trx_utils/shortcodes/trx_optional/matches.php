<?php

// Registar shortcodes [trx_matches] and [trx_latest_matches] in the shortcodes list
add_action('tennisclub_action_shortcodes_list',		'tennisclub_matches_reg_shortcodes');
add_action('tennisclub_action_shortcodes_list',		'tennisclub_latest_matches_reg_shortcodes');
if (function_exists('tennisclub_exists_visual_composer') && tennisclub_exists_visual_composer()){
    add_action('tennisclub_action_shortcodes_list_vc','tennisclub_matches_reg_shortcodes_vc');
    add_action('tennisclub_action_shortcodes_list_vc','tennisclub_latest_matches_reg_shortcodes_vc');
}



// ---------------------------------- [trx_matches] ---------------------------------------

if ( !function_exists( 'tennisclub_sc_matches' ) ) {
    function tennisclub_sc_matches($atts, $content=null){
        if (tennisclub_in_shortcode_blogger()) return '';
        extract(tennisclub_html_decode(shortcode_atts(array(
            // Individual params
            "style" => 'matches-1',
            "cat" => "",
            "align" => "",
            "count" => 4,
            "ids" => "",
            "title" => "",
            "subtitle" => "",
            "description" => "",
            "title_next" => "",
            "subtitle_next" => "",
            "description_next" => "",
            "link_caption" => esc_html__('Learn more', 'trx_utils'),
            "link" => '',
            "scheme" => '',
            // Common params
            "id" => "",
            "class" => "",
            "animation" => "",
            "css" => "",
            "width" => "",
            "height" => "",
            "top" => "",
            "bottom" => "",
            "left" => "",
            "right" => ""
        ), $atts)));
        $columns = 0;

        if (empty($id)) $id = "sc_matches_".str_replace('.', '', mt_rand());
        if (empty($width)) $width = "100%";
        if (!empty($height) && tennisclub_param_is_on($autoheight)) $autoheight = "no";

        $class .= ($class ? ' ' : '') . tennisclub_get_css_position_as_classes($top, $right, $bottom, $left);

        $ws = tennisclub_get_css_dimensions_from_values($width);
        $hs = tennisclub_get_css_dimensions_from_values('', $height);
        $css .= ($hs) . ($ws);

        $output = '<div' . ($id ? ' id="'.esc_attr($id).'_wrap"' : '')
            . ' class="sc_matches_wrap'
            . ($scheme && !tennisclub_param_is_off($scheme) && !tennisclub_param_is_inherit($scheme) ? ' scheme_'.esc_attr($scheme) : '')
            .'">'
            .'<div' . ($id ? ' id="'.esc_attr($id).'"' : '')
            . ' class="sc_matches style_'.esc_attr($style)
            . ' ' . esc_attr(tennisclub_get_template_property($style, 'container_classes'))
            . (!empty($class) ? ' '.esc_attr($class) : '')
            . ($align!='' && $align!='none' ? ' align'.esc_attr($align) : '')
            .'"'
            . (!empty($width) && tennisclub_strpos($width, '%')===false ? ' data-old-width="' . esc_attr($width) . '"' : '')
            . (!empty($height) && tennisclub_strpos($height, '%')===false ? ' data-old-height="' . esc_attr($height) . '"' : '')
            . ($css!='' ? ' style="'.esc_attr($css).'"' : '')
            . (!tennisclub_param_is_off($animation) ? ' data-animation="'.esc_attr(tennisclub_get_animation_classes($animation)).'"' : '')
            . '>';
        // Title, decription and subtitle for the "next matches" block
        $next = '<div class="sc_matches_next">'
            . (!empty($subtitle) && $style == 'matches-1' ? '<h6 class="sc_matches_subtitle sc_item_subtitle">' . trim(tennisclub_strmacros($subtitle_next)) . '</h6>' : '')
            . (!empty($title) ? '<h2 class="sc_matches_title sc_item_title' . (empty($description) ? ' sc_item_title_without_descr' : ' sc_item_title_without_descr') . '">' . trim(tennisclub_strmacros($title_next)) . '</h2>' : '')
            . (!empty($description) && $style == 'matches-1'? '<div class="sc_matches_descr sc_item_descr">' . trim(tennisclub_strmacros($description_next)) . '</div>' : '')
            .'<ul class="sc_matches_list">';

        // Title, decription and subtitle for the "current match" block
        $current = '<div class="sc_matches_current">'
            . (!empty($subtitle) ? '<h6 class="sc_matches_subtitle sc_item_subtitle">' . trim(tennisclub_strmacros($subtitle)) . '</h6>' : '')
            . (!empty($title) ? '<h2 class="sc_matches_title sc_item_title' . (empty($description) ? ' sc_item_title_without_descr' : ' sc_item_title_without_descr') . '">' . trim(tennisclub_strmacros($title)) . '</h2>' : '')
            . (!empty($description) ? '<div class="sc_matches_descr sc_item_descr">' . trim(tennisclub_strmacros($description)) . '</div>' : '')
            .'<ul class="sc_matches_list">';

        global $post;

        $args = array(
            'post_type' => 'matches',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'ignore_sticky_posts' => true,
            'order' => 'asc'
        );

        $args = tennisclub_query_add_sort_order($args, 'date', 'asc');
        $args = tennisclub_query_add_posts_and_cats($args, $ids, 'matches', $cat, 'matches_group');
        $query = new WP_Query( $args );
        $post_number = 0;
        $matches = array();
        $matches['0'] = date_i18n('Y-m-d');
        $matches_ids = array();


        // Create a field matches, where index is post_id and value id match_date
        while ( $query->have_posts() ) {
            $query->the_post();
            $post_number++;
            $args = array(
                'layout' => $style,
                'orderby' => 'date'
            );
            $post_data = tennisclub_get_post_data($args);
            $post_meta = get_post_meta($post_data['post_id'], tennisclub_storage_get('options_prefix') . '_post_options', true);
            $matches[$post_data['post_id']] = $post_meta['match_date'];
        }

        if($count > $post_number) $count = $post_number;
        if($count < 2) $count = 2;
        if (!empty($ids)) {
            $posts = explode(',', str_replace(' ', '', $ids));
            $count = count($posts);
        }

        // Sort matches by the date
        asort($matches);

        // Create a new field, where index is a number and value is post_id
        foreach($matches as $i => $v)
        {
            $matches_ids[] = $i;
        }

        // Get a X nearest matches
        $matches_ids = tennisclub_nearest_match($matches_ids, $count, $post_number);


        // Return matches content
        for($i = 0; $i < $count; $i++) {
            $args = array(
                'layout' => $style,
                'show' => false,
                'number' => $i,
                "descr" => tennisclub_get_custom_option('post_excerpt_maxlength'.($columns > 1 ? '_masonry' : '')),
                "orderby" => 'date',
                'content' => false,
                'terms_list' => false,
                'columns_count' => $columns,
                'tag_id' => $id ? $id . '_' . $i : '',
                'tag_class' => '',
                'tag_animation' => '',
                'tag_css' => '',
                'tag_css_wh' => $ws . $hs
            );

            $post_data = tennisclub_get_post_data($args, $matches_ids[$i]);
            $post_meta = get_post_meta($matches_ids[$i], tennisclub_storage_get('options_prefix') . '_post_options', true);
            $thumb_sizes = tennisclub_get_thumb_sizes(array('layout' => $style));
            $args['name'] = $post_data['post_title'];
            $args['date'] = $post_meta['match_date'];
            $args['time'] = $post_meta['match_time'];
            $args['player_1'] = $post_meta['match_player_1'];
            $args['points_1'] = $post_meta['match_points_1'];
            $args['player_2'] = $post_meta['match_player_2'];
            $args['points_2'] = $post_meta['match_points_2'];
            $args['score'] = $post_meta['match_score'];
            $args['image'] = $post_data['post_thumb'];
            $args['link'] = tennisclub_param_is_on('match_show_link')
                ? (!empty($post_meta['match_link']) ? $post_meta['match_link'] : $post_data['post_link'])
                : '';

            if ($style == 'matches-2' && $i == ceil($count / 2)) $next .= '</ul><ul class="sc_matches_list">';
            if ($style == 'matches-1'){
                $next .= '<li class="sc_match" data-item="#'.esc_attr($id ? $id . '_' . $i : '').'">'
                    .'<div class="sc_match_date">'
                    .'<span class="day">'.date_i18n("d", strtotime($post_meta['match_date'])).'</span>'
                    .'<span class="month">'.date_i18n("M", strtotime($post_meta['match_date'])).'</span>'
                    .'</div>'
                    .'<div class="sc_match_info">'
                    .'<div class="name">'.trim($post_data['post_title']).'</div>'
                    .'<div class="time">'.trim($post_meta['match_time']).', </div>'
                    .'<div class="players">'.trim($post_meta['match_player_1']).' - '.trim($post_meta['match_player_2']).'</div>'
                    .'</div>'
                    .'</li>';
            } else {
                $player_obj = (intval($post_meta['match_player_1']) > 0 ? get_post($post_meta['match_player_1'], OBJECT) : get_page_by_title($post_meta['match_player_1'], OBJECT, 'players'));
                $player_photo_1 = !empty($player_obj) ? wp_get_attachment_url(get_post_thumbnail_id($player_obj->ID)) : '';
                $player_photo_1 = tennisclub_get_resized_image_tag($player_photo_1, 40, 40);

                $player_obj = (intval($post_meta['match_player_2']) > 0 ? get_post($post_meta['match_player_2'], OBJECT) : get_page_by_title($post_meta['match_player_2'], OBJECT, 'players'));
                $player_photo_2 = !empty($player_obj) ? wp_get_attachment_url(get_post_thumbnail_id($player_obj->ID)) : '';
                $player_photo_2 = tennisclub_get_resized_image_tag($player_photo_2, 40, 40);

                $next .= '<li class="sc_match" data-item="#'.esc_attr($id ? $id . '_' . $i : '').'">'
                    .'<div class="sc_match_date">'
                    .'<span class="day">'.date_i18n("d", strtotime($post_meta['match_date'])).'</span>'
                    .'<span class="month">'.date_i18n("M", strtotime($post_meta['match_date'])).'</span>'
                    .'</div>'
                    .'<div class="sc_match_info">'
                    .'<div class="photo">'.trim($player_photo_1).'</div>'
                    .'<div class="name">'.trim($post_meta['match_player_1']).'</div>'
                    .'<div class="vs">VS</div>'
                    .'<div class="name">'.trim($post_meta['match_player_2']).'</div>'
                    .'<div class="photo">'.trim($player_photo_2).'</div>'
                    .'</div>'
                    .'</li>';
            }

            $current .= tennisclub_show_post_layout($args, $post_data);
        }
        wp_reset_postdata();

        if($style == 'matches-1'){
            $output .= $next .'</ul></div><!-- /.sc_matches_next -->';
            $output .= $current;
        }
        else if($style == 'matches-2'){
            $output .= $current;
        }
        $output .= (!empty($link) ? '<div class="sc_matches_button sc_item_button">'.tennisclub_do_shortcode('[trx_button link="'.esc_url($link).'" icon="icon-right"]'.esc_html($link_caption).'[/trx_button]').'</div>' : '')
            . '</ul></div><!-- /.sc_matches_current -->'
            . ($style == 'matches-2' ? $next .'</ul></div><!-- /.sc_matches_next -->' : '')
            . '</div><!-- /.sc_matches -->'
            . '</div><!-- /.sc_matches_wrap -->';

        // Add template specific scripts and styles
        do_action('tennisclub_action_blog_scripts', $style);

        return apply_filters('tennisclub_shortcode_output', $output, 'trx_matches', $atts, $content);
    }
    add_shortcode('trx_matches', 'tennisclub_sc_matches');
}
// ---------------------------------- [/trx_matches] ---------------------------------------


// ---------------------------------- [trx_latest_matches] ---------------------------------------

if ( !function_exists( 'tennisclub_sc_latest_matches' ) ) {
    function tennisclub_sc_latest_matches($atts, $content=null){
        if (tennisclub_in_shortcode_blogger()) return '';
        extract(tennisclub_html_decode(shortcode_atts(array(
            // Individual params
            "style" => 'matches-1',
            "cat" => "",
            "align" => "",
            "count" => 4,
            "title" => "",
            "subtitle" => "",
            "description" => "",
            "link_caption" => esc_html__('Learn more', 'trx_utils'),
            "link" => '',
            "scheme" => '',
            // Common params
            "id" => "",
            "class" => "",
            "animation" => "",
            "css" => "",
            "width" => "",
            "height" => "",
            "top" => "",
            "bottom" => "",
            "left" => "",
            "right" => ""
        ), $atts)));
        $columns = 0;

        if (empty($id)) $id = "sc_latest_matches_".str_replace('.', '', mt_rand());
        if (empty($width)) $width = "100%";
        if (!empty($height) && tennisclub_param_is_on($autoheight)) $autoheight = "no";

        $class .= ($class ? ' ' : '') . tennisclub_get_css_position_as_classes($top, $right, $bottom, $left);

        $ws = tennisclub_get_css_dimensions_from_values($width);
        $hs = tennisclub_get_css_dimensions_from_values('', $height);
        $css .= ($hs) . ($ws);

        $output = '<div' . ($id ? ' id="'.esc_attr($id).'_wrap"' : '')
            . ' class="sc_latest_matches_wrap'
            . ($scheme && !tennisclub_param_is_off($scheme) && !tennisclub_param_is_inherit($scheme) ? ' scheme_'.esc_attr($scheme) : '')
            .'">'
            .'<div' . ($id ? ' id="'.esc_attr($id).'"' : '')
            . ' class="sc_latest_matches style_'.esc_attr($style)
            . ' ' . esc_attr(tennisclub_get_template_property($style, 'container_classes'))
            . (!empty($class) ? ' '.esc_attr($class) : '')
            . ($align!='' && $align!='none' ? ' align'.esc_attr($align) : '')
            .'"'
            . (!empty($width) && tennisclub_strpos($width, '%')===false ? ' data-old-width="' . esc_attr($width) . '"' : '')
            . (!empty($height) && tennisclub_strpos($height, '%')===false ? ' data-old-height="' . esc_attr($height) . '"' : '')
            . ($css!='' ? ' style="'.esc_attr($css).'"' : '')
            . (!tennisclub_param_is_off($animation) ? ' data-animation="'.esc_attr(tennisclub_get_animation_classes($animation)).'"' : '')
            . '>'
            . (!empty($subtitle) ? '<h6 class="sc_latest_matches_subtitle sc_item_subtitle">' . trim(tennisclub_strmacros($subtitle)) . '</h6>' : '')
            . (!empty($title) ? '<h2 class="sc_latest_matches_title sc_item_title' . (empty($description) ? ' sc_item_title_without_descr' : ' sc_item_title_without_descr') . '">' . trim(tennisclub_strmacros($title)) . '</h2>' : '')
            . (!empty($description) ? '<div class="sc_latest_matches_descr sc_item_descr">' . trim(tennisclub_strmacros($description)) . '</div>' : '')
            .'<ul class="sc_latest_matches_list">';

        global $post;

        $args = array(
            'post_type' => 'matches',
            'post_status' => 'publish',
            'ignore_sticky_posts' => true,
            'order' => 'asc'
        );
        $args = tennisclub_query_add_sort_order($args, 'date', 'asc');
        $args = tennisclub_query_add_posts_and_cats($args, '', 'matches', $cat, 'matches_group');
        $query = new WP_Query( $args );

        $matches = array();
        $matches['0'] = date_i18n('Y-m-d');
        $matches_ids = array();

        // Create a field matches, where index is post_id and value id match_date
        while ( $query->have_posts() ) {
            $query->the_post();
            $args = array(
                'layout' => $style,
                'orderby' => 'date'
            );
            $post_data = tennisclub_get_post_data($args);
            $post_meta = get_post_meta($post_data['post_id'], tennisclub_storage_get('options_prefix') . '_post_options', true);
            $matches[$post_data['post_id']] = $post_meta['match_date'];
        }

        // Sort matches by the date
        arsort($matches);

        // Create a new field, where index is a number and value is post_id
        $N = 0;
        $M = 0;
        foreach($matches as $i => $v)
        {
            $matches_ids[$N] = $i;
            if($i == 0) $M = $N;
            $N++;
        }

        // Create a new field with X latest matches
        $matches = array();
        for($i = 0; $i < $count; $i++)
        {
            if(array_key_exists($M + 1, $matches_ids)){
                $matches[$i] = $matches_ids[$M + 1];
                $M++;
            }
        }

        // Return matches content
        for($i = 0; $i < $count; $i++)
        {
            if(array_key_exists($i, $matches)){
                $args = array(
                    'layout' => $style,
                    'show' => false,
                    'number' => $i,
                    "descr" => tennisclub_get_custom_option('post_excerpt_maxlength'.($columns > 1 ? '_masonry' : '')),
                    "orderby" => 'date',
                    'content' => false,
                    'terms_list' => false,
                    'columns_count' => $columns,
                    'tag_id' => $id ? $id . '_' . $i : '',
                    'tag_class' => '',
                    'tag_animation' => '',
                    'tag_css' => '',
                    'tag_css_wh' => $ws . $hs
                );
                $post_data = tennisclub_get_post_data($args, $matches[$i]);
                $post_meta = get_post_meta($matches[$i], tennisclub_storage_get('options_prefix') . '_post_options', true);
                $thumb_sizes = tennisclub_get_thumb_sizes(array('layout' => $style));
                $args['name'] = $post_data['post_title'];
                $args['date'] = $post_meta['match_date'];
                $args['time'] = $post_meta['match_time'];
                $args['player_1'] = $post_meta['match_player_1'];
                $args['points_1'] = $post_meta['match_points_1'];
                $args['player_2'] = $post_meta['match_player_2'];
                $args['points_2'] = $post_meta['match_points_2'];
                $args['score'] = $post_meta['match_score'];
                $args['image'] = $post_data['post_thumb'];
                $args['link'] = tennisclub_param_is_on('match_show_link')
                    ? (!empty($post_meta['match_link']) ? $post_meta['match_link'] : $post_data['post_link'])
                    : '';

                $output .= tennisclub_show_post_layout($args, $post_data);
            }
        }
        wp_reset_postdata();

        $output .= 	'</ul><!-- /.sc_latest_matches_list -->'
            .(!empty($link) ? '<div class="sc_matches_button sc_item_button">'.tennisclub_do_shortcode('[trx_button link="'.esc_url($link).'" icon="icon-right"]'.esc_html($link_caption).'[/trx_button]').'</div>' : '')
            . '</div><!-- /.sc_matches -->'
            . '</div><!-- /.sc_matches_wrap -->';

        // Add template specific scripts and styles
        do_action('tennisclub_action_blog_scripts', $style);

        return apply_filters('tennisclub_shortcode_output', $output, 'trx_latest_matches', $atts, $content);
    }
    add_shortcode('trx_latest_matches', 'tennisclub_sc_latest_matches');
}
// ---------------------------------- [/trx_latest_matches] ---------------------------------------



// Add [trx_matches] in the shortcodes list
if (!function_exists('tennisclub_matches_reg_shortcodes')) {

    function tennisclub_matches_reg_shortcodes() {
        if (tennisclub_storage_isset('shortcodes')) {

            $matches_groups = tennisclub_get_list_terms(false, 'matches_group');
            $matches_styles = tennisclub_get_list_templates('matches');
            $controls 		= tennisclub_get_list_slider_controls();
            $players = tennisclub_get_list_posts(false, array(
                    'post_type'=>'players',
                    'orderby'=>'title',
                    'order'=>'asc',
                    'return'=>'title'
                )
            );
            tennisclub_sc_map_after('trx_chat', array(

                // Matches
                "trx_matches" => array(
                    "title" => esc_html__("Matches", 'trx_utils'),
                    "desc" => wp_kses_data( __("Insert matches list in your page (post)", 'trx_utils') ),
                    "decorate" => true,
                    "container" => false,
                    "params" => array(
                        "style" => array(
                            "title" => esc_html__("Style", 'trx_utils'),
                            "desc" => wp_kses_data( __("Style of the block", 'trx_utils') ),
                            "value" => "matches-1",
                            "type" => "select",
                            "options" => array(
                                'matches-1'  => esc_html__('Style 1', 'trx_utils'),
                                'matches-2' => esc_html__('Style 2', 'trx_utils')
                            ),
                            "type" => "checklist"
                        ),
                        "title" => array(
                            "title" => esc_html__("Title", 'trx_utils'),
                            "desc" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "subtitle" => array(
                            "title" => esc_html__("Subtitle", 'trx_utils'),
                            "desc" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "description" => array(
                            "title" => esc_html__("Description", 'trx_utils'),
                            "desc" => wp_kses_data( __("Short description for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "textarea"
                        ),
                        "title_next" => array(
                            "title" => esc_html__("Title (2)", 'trx_utils'),
                            "desc" => wp_kses_data( __("Title for the NEXT block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "subtitle_next" => array(
                            "title" => esc_html__("Subtitle (2)", 'trx_utils'),
                            "desc" => wp_kses_data( __("Subtitle for the NEXT block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "description_next" => array(
                            "title" => esc_html__("Description (2)", 'trx_utils'),
                            "desc" => wp_kses_data( __("Short description for the NEXT block", 'trx_utils') ),
                            "value" => "",
                            "type" => "textarea"
                        ),
                        "scheme" => array(
                            "title" => esc_html__("Color scheme", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                            "value" => "",
                            "type" => "checklist",
                            "options" => tennisclub_get_sc_param('schemes')
                        ),
                        "cat" => array(
                            "title" => esc_html__("Categories", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select categories (groups) to show team members. If empty - select team members from any category (group) or from IDs list", 'trx_utils') ),
                            "divider" => true,
                            "value" => "",
                            "type" => "select",
                            "style" => "list",
                            "multiple" => true,
                            "options" => tennisclub_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $matches_groups)
                        ),
                        "count" => array(
                            "title" => esc_html__("Number of matches", 'trx_utils'),
                            "desc" => wp_kses_data( __("How many matches will be displayed?", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "ids" => array(
                            "title" => esc_html__("Matches ID list", 'trx_utils'),
                            "desc" => wp_kses_data( __("Comma separated list of posts ID. If set - parameters above are ignored!", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "align" => array(
                            "title" => esc_html__("Alignment", 'trx_utils'),
                            "desc" => wp_kses_data( __("Alignment of the matches block", 'trx_utils') ),
                            "divider" => true,
                            "value" => "",
                            "type" => "checklist",
                            "dir" => "horizontal",
                            "options" => tennisclub_get_sc_param('align')
                        ),
                        "link" => array(
                            "title" => esc_html__("Button URL", 'trx_utils'),
                            "desc" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "link_caption" => array(
                            "title" => esc_html__("Button caption", 'trx_utils'),
                            "desc" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "width" => tennisclub_shortcodes_width(),
                        "height" => tennisclub_shortcodes_height(),
                        "top" => tennisclub_get_sc_param('top'),
                        "bottom" => tennisclub_get_sc_param('bottom'),
                        "left" => tennisclub_get_sc_param('left'),
                        "right" => tennisclub_get_sc_param('right'),
                        "id" => tennisclub_get_sc_param('id'),
                        "class" => tennisclub_get_sc_param('class'),
                        "animation" => tennisclub_get_sc_param('animation'),
                        "css" => tennisclub_get_sc_param('css')
                    )
                )

            ));
        }
    }
}


// Add [trx_latest_matches] in the shortcodes list
if (!function_exists('tennisclub_latest_matches_reg_shortcodes')) {

    function tennisclub_latest_matches_reg_shortcodes() {
        if (tennisclub_storage_isset('shortcodes')) {

            $matches_groups = tennisclub_get_list_terms(false, 'matches_group');
            $matches_styles = tennisclub_get_list_templates('matches');
            $controls 		= tennisclub_get_list_slider_controls();
            $players = tennisclub_get_list_posts(false, array(
                    'post_type'=>'players',
                    'orderby'=>'title',
                    'order'=>'asc',
                    'return'=>'title'
                )
            );
            tennisclub_sc_map_after('trx_chat', array(

                // Latest Matches
                "trx_latest_matches" => array(
                    "title" => esc_html__("Latest Matches", 'trx_utils'),
                    "desc" => wp_kses_data( __("Insert latest matches list in your page (post)", 'trx_utils') ),
                    "decorate" => true,
                    "container" => false,
                    "params" => array(
                        "title" => array(
                            "title" => esc_html__("Title", 'trx_utils'),
                            "desc" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "subtitle" => array(
                            "title" => esc_html__("Subtitle", 'trx_utils'),
                            "desc" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "description" => array(
                            "title" => esc_html__("Description", 'trx_utils'),
                            "desc" => wp_kses_data( __("Short description for the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "textarea"
                        ),
                        "scheme" => array(
                            "title" => esc_html__("Color scheme", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                            "value" => "",
                            "type" => "checklist",
                            "options" => tennisclub_get_sc_param('schemes')
                        ),
                        "cat" => array(
                            "title" => esc_html__("Categories", 'trx_utils'),
                            "desc" => wp_kses_data( __("Select categories (groups) to show team members. If empty - select team members from any category (group) or from IDs list", 'trx_utils') ),
                            "divider" => true,
                            "value" => "",
                            "type" => "select",
                            "style" => "list",
                            "multiple" => true,
                            "options" => tennisclub_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $matches_groups)
                        ),
                        "count" => array(
                            "title" => esc_html__("Number of matches", 'trx_utils'),
                            "desc" => wp_kses_data( __("How many matches will be displayed?", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "align" => array(
                            "title" => esc_html__("Alignment", 'trx_utils'),
                            "desc" => wp_kses_data( __("Alignment of the matches block", 'trx_utils') ),
                            "divider" => true,
                            "value" => "",
                            "type" => "checklist",
                            "dir" => "horizontal",
                            "options" => tennisclub_get_sc_param('align')
                        ),
                        "link" => array(
                            "title" => esc_html__("Button URL", 'trx_utils'),
                            "desc" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "link_caption" => array(
                            "title" => esc_html__("Button caption", 'trx_utils'),
                            "desc" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
                            "value" => "",
                            "type" => "text"
                        ),
                        "width" => tennisclub_shortcodes_width(),
                        "height" => tennisclub_shortcodes_height(),
                        "top" => tennisclub_get_sc_param('top'),
                        "bottom" => tennisclub_get_sc_param('bottom'),
                        "left" => tennisclub_get_sc_param('left'),
                        "right" => tennisclub_get_sc_param('right'),
                        "id" => tennisclub_get_sc_param('id'),
                        "class" => tennisclub_get_sc_param('class'),
                        "animation" => tennisclub_get_sc_param('animation'),
                        "css" => tennisclub_get_sc_param('css')
                    )
                )

            ));
        }
    }
}

// Add [trx_matches] in the VC shortcodes list
if (!function_exists('tennisclub_matches_reg_shortcodes_vc')) {

    function tennisclub_matches_reg_shortcodes_vc() {

        $matches_groups = tennisclub_get_list_terms(false, 'matches_group');
        $matches_styles = tennisclub_get_list_templates('matches');
        $controls		= tennisclub_get_list_slider_controls();
        $players = tennisclub_get_list_posts(false, array(
                'post_type'=>'players',
                'orderby'=>'title',
                'order'=>'asc',
                'return'=>'title'
            )
        );

        // Matches
        vc_map( array(
            "base" => "trx_matches",
            "name" => esc_html__("Matches", 'trx_utils'),
            "description" => wp_kses_data( __("Insert matches list", 'trx_utils') ),
            "category" => esc_html__('Content', 'trx_utils'),
            'icon' => 'icon_trx_matches',
            "class" => "trx_sc_single trx_sc_matches",
            "content_element" => true,
            "is_container" => false,
            "show_settings_on_create" => true,
            "params" => array(
                array(
                    "param_name" => "style",
                    "heading" => esc_html__("Table style", 'trx_utils'),
                    "description" => wp_kses_data( __("Style of the block", 'trx_utils') ),
                    "class" => "",
                    "value" => array(
                        esc_html__('Style 1', 'trx_utils') => 'matches-1',
                        esc_html__('Style 2', 'trx_utils') => 'matches-2'
                    ),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "scheme",
                    "heading" => esc_html__("Color scheme", 'trx_utils'),
                    "description" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                    "class" => "",
                    "value" => array_flip(tennisclub_get_sc_param('schemes')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "title",
                    "heading" => esc_html__("Title", 'trx_utils'),
                    "description" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "subtitle",
                    "heading" => esc_html__("Subtitle", 'trx_utils'),
                    "description" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "description",
                    "heading" => esc_html__("Description", 'trx_utils'),
                    "description" => wp_kses_data( __("Description for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textarea"
                ),
                array(
                    "param_name" => "title_next",
                    "heading" => esc_html__("Title  (2)", 'trx_utils'),
                    "description" => wp_kses_data( __("Title for the NEXT block", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "subtitle_next",
                    "heading" => esc_html__("Subtitle  (2)", 'trx_utils'),
                    "description" => wp_kses_data( __("Subtitle for the NEXT block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "description_next",
                    "heading" => esc_html__("Description  (2)", 'trx_utils'),
                    "description" => wp_kses_data( __("Description for the NEXT block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textarea"
                ),
                array(
                    "param_name" => "cat",
                    "heading" => esc_html__("Categories", 'trx_utils'),
                    "description" => wp_kses_data( __("Select category to show matches. If empty - select matches from any category (group) or from IDs list", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => array_flip(tennisclub_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $matches_groups)),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "count",
                    "heading" => esc_html__("Number of matches", 'trx_utils'),
                    "description" => wp_kses_data( __("How many matches will be displayed?", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "ids",
                    "heading" => esc_html__("Matches ID list", 'trx_utils'),
                    "description" => wp_kses_data( __("Comma separated list of posts ID. If set - parameters above are ignored!", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "align",
                    "heading" => esc_html__("Alignment", 'trx_utils'),
                    "description" => wp_kses_data( __("Alignment of the matches block", 'trx_utils') ),
                    "class" => "",
                    "value" => array_flip(tennisclub_get_sc_param('align')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "link",
                    "heading" => esc_html__("Button URL", 'trx_utils'),
                    "description" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "link_caption",
                    "heading" => esc_html__("Button caption", 'trx_utils'),
                    "description" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                tennisclub_vc_width(),
                tennisclub_vc_height(),
                tennisclub_get_vc_param('margin_top'),
                tennisclub_get_vc_param('margin_bottom'),
                tennisclub_get_vc_param('margin_left'),
                tennisclub_get_vc_param('margin_right'),
                tennisclub_get_vc_param('id'),
                tennisclub_get_vc_param('class'),
                tennisclub_get_vc_param('animation'),
                tennisclub_get_vc_param('css')
            ),
            'js_view' => 'VcTrxSingleView'
        ) );

        class WPBakeryShortCode_Trx_Matches extends Tennisclub_VC_ShortCodeSingle {}
    }
}

// Add [trx_latest_matches] in the VC shortcodes list
if (!function_exists('tennisclub_latest_matches_reg_shortcodes_vc')) {

    function tennisclub_latest_matches_reg_shortcodes_vc() {

        $matches_groups = tennisclub_get_list_terms(false, 'matches_group');
        $matches_styles = tennisclub_get_list_templates('matches');
        $controls		= tennisclub_get_list_slider_controls();
        $players = tennisclub_get_list_posts(false, array(
                'post_type'=>'players',
                'orderby'=>'title',
                'order'=>'asc',
                'return'=>'title'
            )
        );
        // Latest Matches
        vc_map( array(
            "base" => "trx_latest_matches",
            "name" => esc_html__("Latest Matches", 'trx_utils'),
            "description" => wp_kses_data( __("Insert latest matches list", 'trx_utils') ),
            "category" => esc_html__('Content', 'trx_utils'),
            'icon' => 'icon_trx_latest_matches',
            "class" => "trx_sc_single trx_sc_latest_matches",
            "content_element" => true,
            "is_container" => false,
            "show_settings_on_create" => true,
            "params" => array(
                array(
                    "param_name" => "scheme",
                    "heading" => esc_html__("Color scheme", 'trx_utils'),
                    "description" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
                    "class" => "",
                    "value" => array_flip(tennisclub_get_sc_param('schemes')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "title",
                    "heading" => esc_html__("Title", 'trx_utils'),
                    "description" => wp_kses_data( __("Title for the block", 'trx_utils') ),
                    "admin_label" => true,
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "subtitle",
                    "heading" => esc_html__("Subtitle", 'trx_utils'),
                    "description" => wp_kses_data( __("Subtitle for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "description",
                    "heading" => esc_html__("Description", 'trx_utils'),
                    "description" => wp_kses_data( __("Description for the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textarea"
                ),
                array(
                    "param_name" => "cat",
                    "heading" => esc_html__("Categories", 'trx_utils'),
                    "description" => wp_kses_data( __("Select category to show matches. If empty - select matches from any category (group) or from IDs list", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    'dependency' => array(
                        'element' => 'custom',
                        'is_empty' => true
                    ),
                    "class" => "",
                    "value" => array_flip(tennisclub_array_merge(array(0 => esc_html__('- Select category -', 'trx_utils')), $matches_groups)),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "count",
                    "heading" => esc_html__("Number of matches", 'trx_utils'),
                    "description" => wp_kses_data( __("How many matches will be displayed?", 'trx_utils') ),
                    "group" => esc_html__('Query', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "align",
                    "heading" => esc_html__("Alignment", 'trx_utils'),
                    "description" => wp_kses_data( __("Alignment of the matches block", 'trx_utils') ),
                    "class" => "",
                    "value" => array_flip(tennisclub_get_sc_param('align')),
                    "type" => "dropdown"
                ),
                array(
                    "param_name" => "link",
                    "heading" => esc_html__("Button URL", 'trx_utils'),
                    "description" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                array(
                    "param_name" => "link_caption",
                    "heading" => esc_html__("Button caption", 'trx_utils'),
                    "description" => wp_kses_data( __("Caption for the button at the bottom of the block", 'trx_utils') ),
                    "group" => esc_html__('Captions', 'trx_utils'),
                    "class" => "",
                    "value" => "",
                    "type" => "textfield"
                ),
                tennisclub_vc_width(),
                tennisclub_vc_height(),
                tennisclub_get_vc_param('margin_top'),
                tennisclub_get_vc_param('margin_bottom'),
                tennisclub_get_vc_param('margin_left'),
                tennisclub_get_vc_param('margin_right'),
                tennisclub_get_vc_param('id'),
                tennisclub_get_vc_param('class'),
                tennisclub_get_vc_param('animation'),
                tennisclub_get_vc_param('css')
            ),
            'js_view' => 'VcTrxSingleView'
        ) );

        class WPBakeryShortCode_Trx_Latest_Matches extends Tennisclub_VC_ShortCodeSingle {}
    }
}
