<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('tennisclub_sc_emailer_theme_setup')) {
	add_action( 'tennisclub_action_before_init_theme', 'tennisclub_sc_emailer_theme_setup' );
	function tennisclub_sc_emailer_theme_setup() {
		add_action('tennisclub_action_shortcodes_list', 		'tennisclub_sc_emailer_reg_shortcodes');
		if (function_exists('tennisclub_exists_visual_composer') && tennisclub_exists_visual_composer())
			add_action('tennisclub_action_shortcodes_list_vc','tennisclub_sc_emailer_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

//[trx_emailer group=""]

if (!function_exists('tennisclub_sc_emailer')) {	
	function tennisclub_sc_emailer($atts, $content = null) {
		if (tennisclub_in_shortcode_blogger()) return '';
		extract(tennisclub_html_decode(shortcode_atts(array(
			// Individual params
			"group" => "",
			"open" => "yes",
			"align" => "",
			// Common params
			"id" => "",
			"class" => "",
			"css" => "",
			"animation" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => "",
			"width" => "",
			"height" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . tennisclub_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= tennisclub_get_css_dimensions_from_values($width, $height);
		// Load core messages
		tennisclub_enqueue_messages();
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '')
					. ' class="sc_emailer' . ($align && $align!='none' ? ' align' . esc_attr($align) : '') . (tennisclub_param_is_on($open) ? ' sc_emailer_opened' : '') . (!empty($class) ? ' '.esc_attr($class) : '') . '"' 
					. ($css ? ' style="'.esc_attr($css).'"' : '') 
					. (!tennisclub_param_is_off($animation) ? ' data-animation="'.esc_attr(tennisclub_get_animation_classes($animation)).'"' : '')
					. '>'
				. '<form class="sc_emailer_form">'
				. '<input type="text" class="sc_emailer_input" name="email" value="" placeholder="'.esc_attr__('Email', 'trx_utils').'">'
				. '<a href="#" class="sc_emailer_button" title="'.esc_attr__('Submit', 'trx_utils').'" data-group="'.esc_attr($group ? $group : esc_html__('E-mailer subscription', 'trx_utils')).'">Ok</a>'
            .'<div class="mcfwp-agree-input">'
            .'<label class="mcfwp-agree-input"><input type="checkbox" name="i_agree_privacy_policy" value="1" required="" /><span><a href="/privacy-policy/" target="_blank">I have read and agree to the terms &amp; conditions</a></span></label>'
            .'</div>'
            . '</form>'
			. '</div>';
		return apply_filters('tennisclub_shortcode_output', $output, 'trx_emailer', $atts, $content);
	}
	add_shortcode("trx_emailer", "tennisclub_sc_emailer");
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'tennisclub_sc_emailer_reg_shortcodes' ) ) {
	//add_action('tennisclub_action_shortcodes_list', 'tennisclub_sc_emailer_reg_shortcodes');
	function tennisclub_sc_emailer_reg_shortcodes() {
	
		tennisclub_sc_map("trx_emailer", array(
			"title" => esc_html__("E-mail collector", 'trx_utils'),
			"desc" => wp_kses_data( __("Collect the e-mail address into specified group", 'trx_utils') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"group" => array(
					"title" => esc_html__("Group", 'trx_utils'),
					"desc" => wp_kses_data( __("The name of group to collect e-mail address", 'trx_utils') ),
					"value" => "",
					"type" => "text"
				),
				"open" => array(
					"title" => esc_html__("Open", 'trx_utils'),
					"desc" => wp_kses_data( __("Initially open the input field on show object", 'trx_utils') ),
					"divider" => true,
					"value" => "yes",
					"type" => "switch",
					"options" => tennisclub_get_sc_param('yes_no')
				),
				"align" => array(
					"title" => esc_html__("Alignment", 'trx_utils'),
					"desc" => wp_kses_data( __("Align object to left, center or right", 'trx_utils') ),
					"divider" => true,
					"value" => "none",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => tennisclub_get_sc_param('align')
				), 
				"width" => tennisclub_shortcodes_width(),
				"height" => tennisclub_shortcodes_height(),
				"top" => tennisclub_get_sc_param('top'),
				"bottom" => tennisclub_get_sc_param('bottom'),
				"left" => tennisclub_get_sc_param('left'),
				"right" => tennisclub_get_sc_param('right'),
				"id" => tennisclub_get_sc_param('id'),
				"class" => tennisclub_get_sc_param('class'),
				"animation" => tennisclub_get_sc_param('animation'),
				"css" => tennisclub_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'tennisclub_sc_emailer_reg_shortcodes_vc' ) ) {
	//add_action('tennisclub_action_shortcodes_list_vc', 'tennisclub_sc_emailer_reg_shortcodes_vc');
	function tennisclub_sc_emailer_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_emailer",
			"name" => esc_html__("E-mail collector", 'trx_utils'),
			"description" => wp_kses_data( __("Collect e-mails into specified group", 'trx_utils') ),
			"category" => esc_html__('Content', 'trx_utils'),
			'icon' => 'icon_trx_emailer',
			"class" => "trx_sc_single trx_sc_emailer",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "group",
					"heading" => esc_html__("Group", 'trx_utils'),
					"description" => wp_kses_data( __("The name of group to collect e-mail address", 'trx_utils') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "open",
					"heading" => esc_html__("Opened", 'trx_utils'),
					"description" => wp_kses_data( __("Initially open the input field on show object", 'trx_utils') ),
					"class" => "",
					"value" => array(esc_html__('Initially opened', 'trx_utils') => 'yes'),
					"type" => "checkbox"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Alignment", 'trx_utils'),
					"description" => wp_kses_data( __("Align field to left, center or right", 'trx_utils') ),
					"admin_label" => true,
					"class" => "",
					"value" => array_flip(tennisclub_get_sc_param('align')),
					"type" => "dropdown"
				),
				tennisclub_get_vc_param('id'),
				tennisclub_get_vc_param('class'),
				tennisclub_get_vc_param('animation'),
				tennisclub_get_vc_param('css'),
				tennisclub_vc_width(),
				tennisclub_vc_height(),
				tennisclub_get_vc_param('margin_top'),
				tennisclub_get_vc_param('margin_bottom'),
				tennisclub_get_vc_param('margin_left'),
				tennisclub_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Emailer extends Tennisclub_VC_ShortCodeSingle {}
	}
}
?>