<?php if ( $look_for_subs === 'paid-service' ): ?>
		</select>
		<div class="paid-variations"></div>
	</div>
<?php endif; ?>
