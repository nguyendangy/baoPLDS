<?php defined( 'LS_ROOT_FILE' ) || exit; ?>
<script type="text/html" id="tmpl-slider-group-item">
	<div class="slider-item group-item" data-id="">
		<div class="slider-item-wrapper">
			<div class="items">

			</div>

			<div class="info">
				<div class="name">
					<?= lsGetSVGIcon('th-large') ?>
					<ls-span>
						<?= __('Unnamed Group', 'LayerSlider') ?>
					</ls-span>
				</div>
			</div>

		</div>
	</div>
	<div class="ls-hidden">
		<div></div>
	</div>
</script>